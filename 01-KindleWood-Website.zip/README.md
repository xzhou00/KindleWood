# KindleWood: connected prototype

A static website with a demo login connecting Teacher Studio and Book Studio.

## Journey

- Website → Open workspace → choose Teacher → Log in → Teacher Studio.
- Website → Open workspace → choose Author & family → Log in → Book Studio.
- Each studio includes Website and Switch workspace links.

## Publish with GitHub Pages

Upload the contents of this site folder into one repository root, keeping this structure:

    index.html
    app.js
    style.css
    site-links.js
    assets/
    teacher-studio/
    book-studio/
    .nojekyll

Then open repository Settings → Pages → Build and deployment.
Choose Deploy from a branch, select main and / (root), and Save.
Open the URL GitHub provides after deployment completes.
A project URL such as https://USERNAME.github.io/REPOSITORY/ works without editing links.

Do not upload only the ZIP files: GitHub Pages needs their extracted contents.
Do not upload the enclosing site folder itself; index.html belongs at the repository root.

## Local preview

From this site directory run:

    python3 -m http.server 4187 --bind 127.0.0.1

Open http://127.0.0.1:4187/#home.

## Scope

Front-end prototype. Login is a role chooser; it does not authenticate users.
AI and sharing use sample behavior. No messages are sent and no books are published.
Books stay in browser localStorage, separately for the two studios.
The community's curated books and App Store links intentionally open the original external services.
The standalone reading-end comparison images are not included in this release.

## Three packages

01-KindleWood-Website.zip contains the files for the repository root.
02-Teacher-Studio.zip contains teacher-studio/.
03-Book-Studio.zip contains book-studio/.
Extract all three into the same empty folder; the result matches this site directory.
