(()=>{
const app=document.currentScript.dataset.app;
const local=['127.0.0.1','localhost'].includes(location.hostname)&&['4173','4174','4175'].includes(location.port);
const root=local?new URL(location.protocol+'//'+location.hostname+':4173/'):new URL(app==='website'?'./':'../',location.href);
const website=root.href.split('#')[0].split('?')[0];
window.KWLinks={website,teacher:local?website.replace(':4173',':4174'):new URL('teacher-studio/',website).href,books:local?website.replace(':4173',':4175'):new URL('book-studio/',website).href};
window.KWLinks.login=website+'#login';
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('[data-kw-home]').forEach(a=>a.href=website+'#home');
 if(app!=='website'){
 const controls=document.querySelector('.prototype-reset-controls');
 if(controls){const a=document.createElement('a');a.href=window.KWLinks.login;a.textContent='Switch workspace';a.style.cssText='color:inherit;text-decoration:underline;text-underline-offset:3px';controls.append(document.createTextNode(' · '),a)}
 }
});
})();