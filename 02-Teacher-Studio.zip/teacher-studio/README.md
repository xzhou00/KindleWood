# Teacher Studio

Part of the connected KindleWood front-end prototype.
Keep this folder alongside the website's root index.html. Use ../#login to switch workspaces.

No build or dependencies required. Books and drafts are stored in this browser only.
AI output, login, and sharing are simulated. The demo does not create accounts or send messages.
Start over resets this studio and keeps a recoverable previous-session copy.
